import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class Main {
	
	private static Map<String, Employee> calisanlar = new HashMap<>();
	private static double calculatedSalary = 0.0;
	
	public static void main(String[] args) {
		
		//Frame
		        JFrame f = new JFrame("EMPLOYEE SALARY CALCULATOR");
		        
		//Container        
		        Container container = f.getContentPane();
		        container.setBackground(Color.LIGHT_GRAY);
		        
		//Label
		        JLabel l1 = new JLabel("Choose Employee Type");
		        l1.setBounds(160, 20, 200, 20);

		        JLabel l2 = new JLabel("First Name");
		        l2.setBounds(60, 70, 75, 20);
		        JLabel l3 = new JLabel("Last Name");
		        l3.setBounds(60, 120, 75, 20);
		        JLabel l4 = new JLabel("SSN");
		        l4.setBounds(60, 170, 75, 20);
		        JLabel l5 = new JLabel("Search/Update SSN");
		        l5.setBounds(60, 220, 150, 20);
		        
		        JLabel l7 = new JLabel("Gross Sales");
		        l7.setBounds(410, 70, 75, 20);
		        JLabel l8 = new JLabel("Commission Rate");
		        l8.setBounds(410, 120, 120, 20);
		        JLabel l9 = new JLabel("Base Salary");
		        l9.setBounds(410, 170, 75, 20);
		        JLabel l10 = new JLabel("Weekly Salary");
		        l10.setBounds(410, 220, 100, 20);
		        JLabel l11 = new JLabel("Wage");
		        l11.setBounds(410, 270, 50, 20);
		        JLabel l12 = new JLabel("Hours");
		        l12.setBounds(410, 320, 50, 20);
		        
//Güncelleme işlemleri		        
		        JPanel updatePanel = new JPanel();
		        updatePanel.setLayout(null);
		        updatePanel.setBounds(200, 400, 500, 250);
		        updatePanel.setBorder(new LineBorder(Color.GREEN, 4, true));

		        JLabel updateLabel = new JLabel("Update Employee Information");
		        updateLabel.setBounds(120, 10, 200, 20);
		        updatePanel.add(updateLabel);
		        
		        JLabel updateNameLabel = new JLabel("Name");
		        updateNameLabel.setBounds(20, 40, 75, 20);
		        JTextField updateNameTextField = new JTextField();
		        updateNameTextField.setBounds(135, 40, 160, 20);
		        
		        JLabel updateLastNameLabel = new JLabel("Last Name");
		        updateLastNameLabel.setBounds(20, 72, 75, 20);
		        JTextField updateLastNameTextField = new JTextField();
		        updateLastNameTextField.setBounds(135, 72, 160, 20);
		        
		        JLabel updateWeeklySalaryTextLabel = new JLabel("Weekly Salary");
		        updateWeeklySalaryTextLabel.setBounds(20, 104, 120, 20);
		        JTextField updateWeeklySalaryTextField = new JTextField();
		        updateWeeklySalaryTextField.setBounds(135, 104, 160, 20);
		        
		        JLabel updateWageTextLabel = new JLabel("Wage");
		        updateWageTextLabel.setBounds(20, 104, 75, 20);
		        JTextField updateWageTextField = new JTextField();
		        updateWageTextField.setBounds(135, 104, 160, 20);
		        
		        JLabel updateHoursTextLabel = new JLabel("Hours");
		        updateHoursTextLabel.setBounds(20, 136, 75, 20);
		        JTextField updateHoursTextField = new JTextField();
		        updateHoursTextField.setBounds(135, 136, 160, 20);
		        
		        JLabel updateGrossSaleTextLabel = new JLabel("Gross Sale");
		        updateGrossSaleTextLabel.setBounds(20, 104, 75, 20);
		        JTextField updateGrossSaleTextField = new JTextField();
		        updateGrossSaleTextField.setBounds(135, 104, 160, 20);
		        
		        JLabel updateCommissionRateTextLabel = new JLabel("Commission Rate");
		        updateCommissionRateTextLabel.setBounds(20, 136, 100, 20);
		        JTextField updateCommissionRateTextField = new JTextField();
		        updateCommissionRateTextField.setBounds(135, 136, 160, 20);
		        
		        JLabel updateBaseSalaryTextLabel = new JLabel("Base Salary");
		        updateBaseSalaryTextLabel.setBounds(20, 168, 75, 20);
		        JTextField updateBaseSalaryTextField = new JTextField();
		        updateBaseSalaryTextField.setBounds(135, 168, 160, 20);
		        
		        JLabel updateSalaryLabel = new JLabel("Salary");
		        updateSalaryLabel.setBounds(20, 200, 200, 20);
		        
		        JButton updateButton = new JButton("Update");
		        updateButton.setBounds(180, 210, 100, 24);
		        LineBorder roundedBorderUpdate = new LineBorder(Color.BLACK, 2, true);
		        updateButton.setBorder(roundedBorderUpdate);
		        Font buttonFontUpdate = new Font("TIMES_ROMAN", Font.ITALIC, 12);
		        updateButton.setFont(buttonFontUpdate);
		        
		        updatePanel.add(updateNameLabel);
		        updatePanel.add(updateNameTextField);
		        updatePanel.add(updateLastNameLabel);
		        updatePanel.add(updateLastNameTextField);
		        updatePanel.add(updateWeeklySalaryTextLabel);
		        updatePanel.add(updateWeeklySalaryTextField);
		        updatePanel.add(updateWageTextLabel);
		        updatePanel.add(updateWageTextField);
		        updatePanel.add(updateHoursTextLabel);
		        updatePanel.add(updateHoursTextField);
		        updatePanel.add(updateGrossSaleTextField);
		        updatePanel.add(updateGrossSaleTextLabel);
		        updatePanel.add(updateCommissionRateTextField);
		        updatePanel.add(updateCommissionRateTextLabel);
		        updatePanel.add(updateBaseSalaryTextField);
		        updatePanel.add(updateBaseSalaryTextLabel);
		        updatePanel.add(updateButton);
		        updatePanel.add(updateSalaryLabel);
		        
		//ComboBox
		        String arr[] = {"Salaried Employee", "Hourly Employee", "Commission Employee", "Base Plus Commission Employee", "None"};
		        JComboBox<String> c1 = new JComboBox<>(arr);
		        c1.setBounds(315, 22, 230, 22);
		        c1.setSelectedItem(null); 
		        LineBorder roundedBorder4 = new LineBorder(Color.BLACK, 1, true);
		        c1.setBorder(roundedBorder4);
		        Font buttonFont4 = new Font("Arial", Font.BOLD, 12);
		        c1.setFont(buttonFont4);
		        
		//TextField
		        JTextField t2 = new JTextField();
		        t2.setBounds(200, 70, 160, 20);
		        JTextField t3 = new JTextField();
		        t3.setBounds(200, 120, 160, 20);
		        JTextField t4 = new JTextField();
		        t4.setBounds(200, 170, 160, 20);
		        JTextField t5 = new JTextField();
		        t5.setBounds(200, 220, 160, 20);
		        
		        JTextField t7 = new JTextField();
		        t7.setBounds(560, 70, 160, 20);
		        JTextField t8 = new JTextField();
		        t8.setBounds(560, 120, 160, 20);
		        JTextField t9 = new JTextField();
		        t9.setBounds(560, 170, 160, 20);
		        JTextField t10 = new JTextField();
		        t10.setBounds(560, 220, 160, 20);
		        JTextField t11 = new JTextField();
		        t11.setBounds(560, 270, 160, 20);
		        JTextField t12 = new JTextField();
		        t12.setBounds(560, 320, 160, 20);
		        
		//TextFieldların ComboBox seçimine göre oluşması        
		        c1.addActionListener(new ActionListener() {
		        	
		            @Override
		            public void actionPerformed(ActionEvent e) {
		                String selectedEmployeeType = (String) c1.getSelectedItem();
		                
		                updatePanel.setVisible(false);
                        f.setSize(800 , 500);
		// Başlangıçta gereksiz text alanlarını devre dışı bırak
		                t4.setEnabled(false);
		                t7.setEnabled(false);
		                t8.setEnabled(false);
		                t9.setEnabled(false);
		                t10.setEnabled(false);
		                t11.setEnabled(false);
		                t12.setEnabled(false);
		                
		                t2.setText("");
		                t3.setText("");
		                t4.setText("");
		                t5.setText("");
		                t7.setText("");
		                t8.setText("");
		                t9.setText("");
		                t10.setText("");
		                t11.setText("");
		                t12.setText("");
		                
		                if ("Salaried Employee".equals(selectedEmployeeType)) {
		                	t2.setEnabled(true);
		                	t3.setEnabled(true);
		                	t5.setEnabled(true);
		                    t10.setEnabled(true);
		                } else if ("Hourly Employee".equals(selectedEmployeeType)) {
		                	t2.setEnabled(true);
		                	t3.setEnabled(true);
		                	t5.setEnabled(true);
		                    t11.setEnabled(true);
		                    t12.setEnabled(true);
		                } else if ("Commission Employee".equals(selectedEmployeeType)) {
		                	t2.setEnabled(true);
		                	t3.setEnabled(true);
		                	t5.setEnabled(true);
		                    t7.setEnabled(true);
		                    t8.setEnabled(true);
		                } else if ("Base Plus Commission Employee".equals(selectedEmployeeType)) {
		                	t2.setEnabled(true);
		                	t3.setEnabled(true);
		                	t5.setEnabled(true);
		                    t7.setEnabled(true);
		                    t8.setEnabled(true);
		                    t9.setEnabled(true);
		                } else if ("None".equals(selectedEmployeeType)) {
		                	t2.setEnabled(false);
		                	t3.setEnabled(false);
		                	t5.setEnabled(false);
		                	t7.setEnabled(false);
		                    t8.setEnabled(false);
		                    t9.setEnabled(false);
		                    t10.setEnabled(false);
		                    t11.setEnabled(false);
		                    t12.setEnabled(false);
		                    
		                    t2.setText("");
		                    t3.setText("");
		                    t4.setText("");
		                    t5.setText("");
		                    t7.setText("");
		                    t8.setText("");
		                    t9.setText("");
		                    t10.setText("");
		                    t11.setText("");
		                    t12.setText("");
		                }
		            }
		        });
		
		        JButton btnAdd,btnSearchBySSN,btnUpdateBySSN,btnCleanTextFields;
		      //Add
		        btnAdd = new JButton("Add");
		        btnAdd.setBounds(200,360,56,24);
		        LineBorder roundedBorder = new LineBorder(Color.BLACK, 2, true);
		        btnAdd.setBorder(roundedBorder);
		        Font buttonFont = new Font("TIMES_ROMAN", Font.ITALIC, 12);
		        btnAdd.setFont(buttonFont);
		        
		        btnAdd.addActionListener(new ActionListener() {
		            @Override
		            public void actionPerformed(ActionEvent e) {
		                // Text alanlarından değerleri al
		                String ad = t2.getText();
		                String soyad = t3.getText();
		                String ssn = t4.getText();
		                
		                // Sayısal değerleri kontrol et ve çevir
		                double brutSatis = parseDouble(t7.getText());
		                double komisyonOrani = parseDouble(t8.getText());
		                double sabitMaas = parseDouble(t9.getText());
		                double haftalikMaas = parseDouble(t10.getText());
		                double saatlikUcret = parseDouble(t11.getText());
		                double calismaSaatleri = parseDouble(t12.getText());
		                
		                String seciliCalisanTuru = (String) c1.getSelectedItem();

		                Employee calisan = null;
		                
		                switch (seciliCalisanTuru) {
		                    case "Salaried Employee":
		                        calisan = new SalariedEmployee(ad, soyad, ssn, haftalikMaas);
		                        break;
		                    case "Hourly Employee":
		                        calisan = new HourlyEmployee(ad, soyad, ssn, saatlikUcret, calismaSaatleri);
		                        break;
		                    case "Commission Employee":
		                        calisan = new CommissionEmployee(ad, soyad, ssn, brutSatis, komisyonOrani);
		                        break;
		                    case "Base Plus Commission Employee":
		                        calisan = new BasePlusCommissionEmployee(ad, soyad, ssn, brutSatis, komisyonOrani, sabitMaas);
		                        break;
		                }
		                if (seciliCalisanTuru.equals("Salaried Employee")) {
		                    if (ad.isEmpty() || soyad.isEmpty() || t10.getText().isEmpty() || haftalikMaas < 0) {
		                        LineBorder roundedBorder4 = new LineBorder(Color.RED, 3, true);
		                        t2.setBorder(roundedBorder4);
		                        t3.setBorder(roundedBorder4);
		                        t10.setBorder(roundedBorder4);
		                        JOptionPane.showMessageDialog(f, "Please fill in your name, surname, and required fields. Weekly salary must be a non-negative value.", "ERROR", JOptionPane.ERROR_MESSAGE);
		                        t2.setText("");
		                        t3.setText("");
		                        t4.setText("");
		                        t5.setText("");
		                        t7.setText("");
		                        t8.setText("");
		                        t9.setText("");
		                        t10.setText("");
		                        t11.setText("");
		                        t12.setText("");
		                        LineBorder roundedBorder5 = new LineBorder(Color.RED, 0, true);
		                        t2.setBorder(roundedBorder5);
		                        t3.setBorder(roundedBorder5);
		                        t10.setBorder(roundedBorder5);
		                        return;
		                    }
		                    SalariedEmployee salariedEmployee = (SalariedEmployee) calisan;
		                    double paymentAmount = salariedEmployee.getPaymentAmount();
		                    String resultText = "Payment Amount for Salaried Employee: " + paymentAmount;
		                    JOptionPane.showMessageDialog(f, resultText, "Payment Amount", JOptionPane.INFORMATION_MESSAGE); 
		                }
		                
		                if (seciliCalisanTuru.equals("Hourly Employee")) {
		                    if (ad.isEmpty() || soyad.isEmpty() || t11.getText().isEmpty() || t12.getText().isEmpty() || saatlikUcret < 0 || calismaSaatleri < 0 || calismaSaatleri > 168) {
		                        LineBorder roundedBorder4 = new LineBorder(Color.RED, 3, true);
		                        t2.setBorder(roundedBorder4);
		                        t3.setBorder(roundedBorder4);
		                        t11.setBorder(roundedBorder4);
		                        t12.setBorder(roundedBorder4);
		                        JOptionPane.showMessageDialog(f, "Please fill in your name, surname, and required fields. Hourly rate must be a non-negative value, and working hours must be greater than 0 and less than to 168.", "ERROR", JOptionPane.ERROR_MESSAGE);
		                        t2.setText("");
		                        t3.setText("");
		                        t4.setText("");
		                        t5.setText("");
		                        t7.setText("");
		                        t8.setText("");
		                        t9.setText("");
		                        t10.setText("");
		                        t11.setText("");
		                        t12.setText("");
		                        LineBorder roundedBorder5 = new LineBorder(Color.RED, 0, true);
		                        t2.setBorder(roundedBorder5);
		                        t3.setBorder(roundedBorder5);
		                        t11.setBorder(roundedBorder5);
		                        t12.setBorder(roundedBorder5);
		                        return;
		                    }
		                    HourlyEmployee hourlyEmployee = (HourlyEmployee) calisan;
		                    double paymentAmount = hourlyEmployee.getPaymentAmount();
		                    String resultText = "Payment Amount for Hourly Employee: " + paymentAmount;
		                    JOptionPane.showMessageDialog(f, resultText, "Payment Amount", JOptionPane.INFORMATION_MESSAGE);
		                }
		                
		                if (seciliCalisanTuru.equals("Commission Employee")) {
		                    if (ad.isEmpty() || soyad.isEmpty() || t7.getText().isEmpty() || t8.getText().isEmpty() || brutSatis < 0 || komisyonOrani < 0 || komisyonOrani > 1) {
		                        LineBorder roundedBorder4 = new LineBorder(Color.RED, 3, true);
		                        t2.setBorder(roundedBorder4);
		                        t3.setBorder(roundedBorder4);
		                        t7.setBorder(roundedBorder4);
		                        t8.setBorder(roundedBorder4);
		                        JOptionPane.showMessageDialog(f, "Please fill in your name, surname, and required fields. Gross sales must be a non-negative value, and commission rate must be between 0 and 1.", "ERROR", JOptionPane.ERROR_MESSAGE);
		                        t2.setText("");
		                        t3.setText("");
		                        t4.setText("");
		                        t5.setText("");
		                        t7.setText("");
		                        t8.setText("");
		                        t9.setText("");
		                        t10.setText("");
		                        t11.setText("");
		                        t12.setText("");
		                        LineBorder roundedBorder5 = new LineBorder(Color.RED, 0, true);
		                        t2.setBorder(roundedBorder5);
		                        t3.setBorder(roundedBorder5);
		                        t7.setBorder(roundedBorder5);
		                        t8.setBorder(roundedBorder5);
		                        return;
		                    }
		                    CommissionEmployee commissonEmployee = (CommissionEmployee) calisan;
		                    double paymentAmount = commissonEmployee.getPaymentAmount();
		                    String resultText = "Payment Amount for Hourly Employee: " + paymentAmount;
		                    JOptionPane.showMessageDialog(f, resultText, "Payment Amount", JOptionPane.INFORMATION_MESSAGE);
		                }
		                
		                if (seciliCalisanTuru.equals("Base Plus Commission Employee")) {
		                    if (ad.isEmpty() || soyad.isEmpty() || t7.getText().isEmpty() || t8.getText().isEmpty() || t9.getText().isEmpty() || brutSatis < 0 || komisyonOrani < 0 || komisyonOrani > 1 || sabitMaas < 0) {
		                        LineBorder roundedBorder4 = new LineBorder(Color.RED, 3, true);
		                        t2.setBorder(roundedBorder4);
		                        t3.setBorder(roundedBorder4);
		                        t7.setBorder(roundedBorder4);
		                        t8.setBorder(roundedBorder4);
		                        t9.setBorder(roundedBorder4);
		                        JOptionPane.showMessageDialog(f, "Please fill in your name, surname, and required fields. Gross sales must be a non-negative value, commission rate must be between 0 and 1, and fixed salary must be a non-negative value.", "ERROR", JOptionPane.ERROR_MESSAGE);
		                        t2.setText("");
		                        t3.setText("");
		                        t4.setText("");
		                        t5.setText("");
		                        t7.setText("");
		                        t8.setText("");
		                        t9.setText("");
		                        t10.setText("");
		                        t11.setText("");
		                        t12.setText("");
		                        LineBorder roundedBorder5 = new LineBorder(Color.RED, 0, true);
		                        t2.setBorder(roundedBorder5);
		                        t3.setBorder(roundedBorder5);
		                        t7.setBorder(roundedBorder5);
		                        t8.setBorder(roundedBorder5);
		                        t9.setBorder(roundedBorder5);
		                        return;
		                    }
		                    BasePlusCommissionEmployee basePlusCommissonEmployee = (BasePlusCommissionEmployee) calisan;
		                    double paymentAmount = basePlusCommissonEmployee.getPaymentAmount();
		                    String resultText = "Payment Amount for Hourly Employee: " + paymentAmount;
		                    JOptionPane.showMessageDialog(f, resultText, "Payment Amount", JOptionPane.INFORMATION_MESSAGE);
		                }
		                
		                String generatedSSN = generateSSN();
		                if(seciliCalisanTuru != null) {
		                	t4.setText(generatedSSN);
		                    JOptionPane.showMessageDialog(f, "Generated SSN: " + generatedSSN, "Generated SSN", JOptionPane.INFORMATION_MESSAGE);
		                }
		                
		                calisanlar.put(t4.getText(), calisan);
		            }
		            
		            private double parseDouble(String metin) {
		                if (metin.isEmpty()) {
		                    return 0.0;
		                }
		                return Double.parseDouble(metin);
		            }
		            
		        });
		        
		      //SearchBySSN   
		        btnSearchBySSN = new JButton("Search by SSN");
		        btnSearchBySSN.setBounds(265,360,100,24);
		        LineBorder roundedBorder1 = new LineBorder(Color.BLACK, 2, true);
		        btnSearchBySSN.setBorder(roundedBorder1);
		        Font buttonFont1 = new Font("TIMES_ROMAN", Font.ITALIC, 12);
		        btnSearchBySSN.setFont(buttonFont1);
		        
		        btnSearchBySSN.addActionListener(new ActionListener() {
		            @Override
		            public void actionPerformed(ActionEvent e) {
		                String searchSSN = t5.getText();
		                Employee foundEmployee = calisanlar.get(searchSSN);

		                if (foundEmployee != null) {
		                    JOptionPane.showMessageDialog(f, "Employee found!\n" + "Name : " + foundEmployee.getFirstName() + "\nSurname : " + foundEmployee.getLastName() + "\n" + foundEmployee, "Employee Found",JOptionPane.INFORMATION_MESSAGE);
		                } else {
		                    JOptionPane.showMessageDialog(f, "Employee not found!", "Employee Not Found",JOptionPane.ERROR_MESSAGE);     
		                }
		            }
		        });
		        
		      //Update By SSN        
		        btnUpdateBySSN = new JButton("Update by SSN");
		        btnUpdateBySSN.setBounds(375,360,100,24);
		        LineBorder roundedBorder2 = new LineBorder(Color.BLACK, 2, true);
		        btnUpdateBySSN.setBorder(roundedBorder2);
		        Font buttonFont2 = new Font("TIMES_ROMAN", Font.ITALIC, 12);
		        btnUpdateBySSN.setFont(buttonFont2);
		        
		        btnUpdateBySSN.addActionListener(new ActionListener() {
		            @Override
		            public void actionPerformed(ActionEvent e) {
		                String updateSSN = t5.getText();
		                Employee existingEmployee = calisanlar.get(updateSSN);
		                
		                if (existingEmployee != null) {
		                    updateNameTextField.setText(existingEmployee.getFirstName());
		                    updateLastNameTextField.setText(existingEmployee.getLastName());
		                    
		                    if (existingEmployee instanceof SalariedEmployee) {
		                        updateWeeklySalaryTextField.setText(String.valueOf(((SalariedEmployee) existingEmployee).getWeeklySalary()));
		                        calculatedSalary = ((SalariedEmployee) existingEmployee).getPaymentAmount();
		                        updateSalaryLabel.setText("Salary: " + calculatedSalary);
		                        showSalariedEmployeeFields(true);
		                    } else if (existingEmployee instanceof HourlyEmployee) {
		                    	updateWageTextField.setText(String.valueOf(((HourlyEmployee) existingEmployee).getWage()));
		                    	updateHoursTextField.setText(String.valueOf(((HourlyEmployee) existingEmployee).getHours()));
		                    	calculatedSalary = ((HourlyEmployee) existingEmployee).getPaymentAmount();
                                updateSalaryLabel.setText("Salary: " + calculatedSalary);
		                    	showHourlyEmployeeFields(true);
		                    } else if (existingEmployee instanceof CommissionEmployee) {
		                    	updateGrossSaleTextField.setText(String.valueOf(((CommissionEmployee) existingEmployee).getGrossSales()));
		                    	updateCommissionRateTextField.setText(String.valueOf(((CommissionEmployee) existingEmployee).getCommissionRate()));
		                    	calculatedSalary = ((CommissionEmployee) existingEmployee).getPaymentAmount();
                                updateSalaryLabel.setText("Salary: " + calculatedSalary);
		                    	showCommissionEmployeeFields(true);
		                    } else if (existingEmployee instanceof BasePlusCommissionEmployee) {
		                    	updateGrossSaleTextField.setText(String.valueOf(((BasePlusCommissionEmployee) existingEmployee).getGrossSale()));
		                    	updateCommissionRateTextField.setText(String.valueOf(((BasePlusCommissionEmployee) existingEmployee).getCommissionRate()));
		                    	updateBaseSalaryTextField.setText(String.valueOf(((BasePlusCommissionEmployee) existingEmployee).getBaseSalary()));
		                    	calculatedSalary = ((BasePlusCommissionEmployee) existingEmployee).getPaymentAmount();
                                updateSalaryLabel.setText("Salary: " + calculatedSalary);
		                    	showBasePlusCommissionEmployeeFields(true);
		                    }
		                    
		                    updatePanel.setVisible(true);
		                    
		                } else {
		                    JOptionPane.showMessageDialog(f, "Employee with SSN " + updateSSN + " not found.",
		                            "Employee Not Found", JOptionPane.ERROR_MESSAGE);
		                }
		                
		             // Update button action
	                    updateButton.addActionListener (new ActionListener() {
	                        @Override
	                        public void actionPerformed(ActionEvent s) {
	                            String updatedName = updateNameTextField.getText();
	                            String updatedLastName = updateLastNameTextField.getText();

	                            existingEmployee.setFirstName(updatedName);
	                            existingEmployee.setLastName(updatedLastName);

	                            if (existingEmployee != null) {
	                            	String updateMessage = "";
	                                if (existingEmployee instanceof SalariedEmployee) {
	                                    double updatedWeeklySalary = Double.parseDouble(updateWeeklySalaryTextField.getText());
	                                    ((SalariedEmployee) existingEmployee).setWeeklySalary(updatedWeeklySalary);
	                                    calculatedSalary = ((SalariedEmployee) existingEmployee).getPaymentAmount();
	                                    updateSalaryLabel.setText("Salary: " + calculatedSalary);
	                                    updateMessage = "Salaried Employee updated successfully!";
	                                } else if (existingEmployee instanceof HourlyEmployee) {
	                                    double updateWage = Double.parseDouble(updateWageTextField.getText());
	                                    ((HourlyEmployee) existingEmployee).setWage(updateWage);
	                                    double updateHours = Double.parseDouble(updateHoursTextField.getText());
	                                    ((HourlyEmployee) existingEmployee).setHours(updateHours);
	                                    calculatedSalary = ((HourlyEmployee) existingEmployee).getPaymentAmount();
	                                    updateSalaryLabel.setText("Salary: " + calculatedSalary);
	                                    updateMessage = "Hourly Employee updated successfully!";
	                                } else if (existingEmployee instanceof CommissionEmployee) {
	                                    double updateGrossSale = Double.parseDouble(updateGrossSaleTextField.getText());
	                                    ((CommissionEmployee) existingEmployee).setGrossSales(updateGrossSale);
	                                    double updateCommissionRate = Double.parseDouble(updateCommissionRateTextField.getText());
	                                    ((CommissionEmployee) existingEmployee).setCommissionRate(updateCommissionRate);
	                                    calculatedSalary = ((CommissionEmployee) existingEmployee).getPaymentAmount();
	                                    updateSalaryLabel.setText("Salary: " + calculatedSalary);
	                                    updateMessage = "Commission Employee updated successfully!";
	                                } else if (existingEmployee instanceof BasePlusCommissionEmployee) {
	                                    double updateGrossSale = Double.parseDouble(updateGrossSaleTextField.getText());
	                                    ((BasePlusCommissionEmployee) existingEmployee).setGrossSale(updateGrossSale);
	                                    double updateCommissionRate = Double.parseDouble(updateCommissionRateTextField.getText());
	                                    ((BasePlusCommissionEmployee) existingEmployee).setCommissionRate(updateCommissionRate);
	                                    double updateBaseSalary = Double.parseDouble(updateBaseSalaryTextField.getText());
	                                    ((BasePlusCommissionEmployee) existingEmployee).setBaseSalary(updateBaseSalary);
	                                    calculatedSalary = ((BasePlusCommissionEmployee) existingEmployee).getPaymentAmount();
	                                    updateSalaryLabel.setText("Salary: " + calculatedSalary);
	                                    updateMessage = "Base Plus Commission Employee updated successfully!";
	                                    
	                                }
	                                JOptionPane.showMessageDialog(f, updateMessage, "Information",JOptionPane.INFORMATION_MESSAGE);
	                            }
	                          calculatedSalary = 0.0;
	                          updatePanel.setVisible(false);
	                          f.setSize(800 , 500);
	                          
	                          ActionListener[] updateButtonListeners = updateButton.getActionListeners();
	                          for (ActionListener listener : updateButtonListeners) {
	                              updateButton.removeActionListener(listener);
	                          }
	                        }
	                    });    
		            }
		            
		                private void showSalariedEmployeeFields(boolean show) {
		                    updateWageTextLabel.setVisible(!show);
		                    updateWageTextField.setVisible(!show);
		                    updateHoursTextLabel.setVisible(!show);
		                    updateHoursTextField.setVisible(!show);
		                    updateWeeklySalaryTextLabel.setVisible(show);
		                    updateWeeklySalaryTextField.setVisible(show);
		                    updateGrossSaleTextLabel.setVisible(!show);
		                    updateGrossSaleTextField.setVisible(!show);
		                    updateCommissionRateTextLabel.setVisible(!show);
		                    updateCommissionRateTextField.setVisible(!show);
		                    updateBaseSalaryTextLabel.setVisible(!show);
		                    updateBaseSalaryTextField.setVisible(!show);
		                    
		                    if(true) {
		                      	  updatePanel.setVisible(true);
			                          f.setSize(800 , 700);
		                        }
		                }
		                private void showHourlyEmployeeFields(boolean show) {
		                    updateWageTextLabel.setVisible(show);
		                    updateWageTextField.setVisible(show);
		                    updateHoursTextLabel.setVisible(show);
		                    updateHoursTextField.setVisible(show);
		                    updateWeeklySalaryTextLabel.setVisible(!show);
		                    updateWeeklySalaryTextField.setVisible(!show);
		                    updateGrossSaleTextLabel.setVisible(!show);
		                    updateGrossSaleTextField.setVisible(!show);
		                    updateCommissionRateTextLabel.setVisible(!show);
		                    updateCommissionRateTextField.setVisible(!show);
		                    updateBaseSalaryTextLabel.setVisible(!show);
		                    updateBaseSalaryTextField.setVisible(!show);
		                    
		                    if(true) {
		                      	  updatePanel.setVisible(true);
			                          f.setSize(800 , 700);
		                        }
		                }
		                private void showCommissionEmployeeFields(boolean show) {
		                    updateWageTextLabel.setVisible(!show);
		                    updateWageTextField.setVisible(!show);
		                    updateHoursTextLabel.setVisible(!show);
		                    updateHoursTextField.setVisible(!show);
		                    updateWeeklySalaryTextLabel.setVisible(!show);
		                    updateWeeklySalaryTextField.setVisible(!show);
		                    updateGrossSaleTextLabel.setVisible(show);
		                    updateGrossSaleTextField.setVisible(show);
		                    updateCommissionRateTextLabel.setVisible(show);
		                    updateCommissionRateTextField.setVisible(show);
		                    updateBaseSalaryTextLabel.setVisible(!show);
		                    updateBaseSalaryTextField.setVisible(!show);
		                    
		                    if(true) {
		                      	  updatePanel.setVisible(true);
			                          f.setSize(800 , 700);
		                        }
		                }
		                private void showBasePlusCommissionEmployeeFields(boolean show) {
		                    updateWageTextLabel.setVisible(!show);
		                    updateWageTextField.setVisible(!show);
		                    updateHoursTextLabel.setVisible(!show);
		                    updateHoursTextField.setVisible(!show);
		                    updateWeeklySalaryTextLabel.setVisible(!show);
		                    updateWeeklySalaryTextField.setVisible(!show);
		                    updateGrossSaleTextLabel.setVisible(show);
		                    updateGrossSaleTextField.setVisible(show);
		                    updateCommissionRateTextLabel.setVisible(show);
		                    updateCommissionRateTextField.setVisible(show);
		                    updateBaseSalaryTextLabel.setVisible(show);
		                    updateBaseSalaryTextField.setVisible(show);
		                
		                if(true) {
	                      	  updatePanel.setVisible(true);
		                          f.setSize(800 , 700);
	                        }
		        }});
		        
		      //Clean Text Fields        
		        btnCleanTextFields = new JButton("Clean textFields");
		        btnCleanTextFields.setBounds(485,360,100,24);
		        LineBorder roundedBorder3 = new LineBorder(Color.BLACK, 2, true);
		        btnCleanTextFields.setBorder(roundedBorder3);
		        Font buttonFont3 = new Font("TIMES_ROMAN", Font.ITALIC, 12);
		        btnCleanTextFields.setFont(buttonFont3);
		        
		        btnCleanTextFields.addActionListener(new ActionListener() {
		        	
					@Override
					public void actionPerformed(ActionEvent e) {
						t2.setText("");
						t3.setText("");
						t4.setText("");
						t5.setText("");
						//t6.setText("");
						
						t7.setText("");
						t8.setText("");
						t9.setText("");
						t10.setText("");
						t11.setText("");
						t12.setText("");
						if(true) {
                      	  updatePanel.setVisible(false);
	                          f.setSize(800 , 500);
                        }
					}
				});
		        
		      //AddFrame
		        f.add(l1);
		        f.add(c1);

		        f.add(l2);
		        f.add(l3);
		        f.add(l4);
		        f.add(l5);
		        //f.add(l6);
		        f.add(l7);
		        f.add(l8);
		        f.add(l9);
		        f.add(l10);
		        f.add(l11);
		        f.add(l12);

		        f.add(t2);
		        f.add(t3);
		        f.add(t4);
		        f.add(t5);
		        //f.add(t6);
		        f.add(t7);
		        f.add(t8);
		        f.add(t9);
		        f.add(t10);
		        f.add(t11);
		        f.add(t12);
		        
		        f.add(btnAdd);
		        f.add(btnSearchBySSN);
		        f.add(btnUpdateBySSN);
		        f.add(btnCleanTextFields);
		        
		        f.setSize(800 , 500);
		        f.setLocationRelativeTo(null);
		        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		        f.setLayout(null);
		        f.setVisible(true);
		        updatePanel.setVisible(false);
		        f.add(updatePanel);
	}
	
	private static int ssnCounter3 = 1111;
    private static int ssnCounter2 = 11;
    private static int ssnCounter1 = 111;
    
	private static String generateSSN() {
        int firstSegmentCounter = ssnCounter1;
        int secondSegmentCounter = ssnCounter2;
        int thirdSegmentCounter = ssnCounter3;

        String formattedSSN = String.format("%03d-%02d-%04d", firstSegmentCounter, secondSegmentCounter, thirdSegmentCounter);
        
        ssnCounter1 += 111;
        ssnCounter2 += 11;
        ssnCounter3 += 1111;
        return formattedSSN;
    }
}
public interface IPayable {
	
	double getPaymentAmount();
	
}

public class HourlyEmployee extends Employee{
	
	private double wage;
	private double hours;
	
	public HourlyEmployee(String firstName, String lastName, String sSN, double wage, double hours) {
		super(firstName, lastName, sSN);
		this.wage = wage;
		this.hours = hours;
	}

	public double getWage() {
		return wage;
	}

	public void setWage(double wage) {
		if(wage >= 0) {
			this.wage = wage;
		}
		else {
			throw new IllegalArgumentException("Hourly wage must be >= 0");
		}
	}

	public double getHours() {
		return hours;
	}

	public void setHours(double hours) {
		if(0 < hours || hours > 168) {
			this.hours = hours;
		}
		else {
			throw new IllegalArgumentException("Hours must be >= 0 and < 168");
		}
	}
	
	@Override
	public double getPaymentAmount() {
		if(getHours() <= 40) {
			return getWage() * getHours();
		}
		else if(getHours() > 40) {
			return 40 * getWage() + (getHours() - 40) * getWage() - 1.5;
		}
		else {
			throw new IllegalArgumentException("Working hours cannot be negative");
		}
	}
	
	@Override
	public String toString() {
		return String.format("Wage : %s%nHours : %s" , 
				             getWage(), getHours());
	}
	
}

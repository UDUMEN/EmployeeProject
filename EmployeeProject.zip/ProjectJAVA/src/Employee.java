public abstract class Employee implements IPayable {
	
	private String FirstName;
	private String LastName;
	private String SSN;

	public Employee(String firstName, String lastName, String sSN) {
		FirstName = firstName;
		LastName = lastName;
		SSN = sSN;
	}

	public String getLastName() {
		return LastName;
	}
	
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	
	public String getFirstName() {
		return FirstName;
	}
	
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	
	public String getSSN() {
		return SSN;
	}

	public void setSSN(String sSN) {
		SSN = sSN;
	}
	
	@Override
	public String toString() {
		return String.format("First Name : %s%nLast Name : %s" , 
				             getFirstName(), getLastName());
	}

	@Override
	public double getPaymentAmount() {
		return 0;
	}
	
}

public class BasePlusCommissionEmployee extends Employee{
	
	private double grossSale;
	private double commissionRate;
	private double baseSalary;
	
	public BasePlusCommissionEmployee(String firstName, String lastName, String sSN, double grossSale,double commissionRate, double baseSalary) {
		super(firstName, lastName, sSN);
		this.grossSale = grossSale;
		this.commissionRate = commissionRate;
		this.baseSalary = baseSalary;
	}

	public double getGrossSale() {
		return grossSale;
	}

	public void setGrossSale(double grossSale) {
		this.grossSale = grossSale;
	}

	public double getCommissionRate() {
		return commissionRate;
	}

	public void setCommissionRate(double commissionRate) {
		this.commissionRate = commissionRate;
	}

	public double getBaseSalary() {
		return baseSalary;
	}

	public void setBaseSalary(double baseSalary) {
			this.baseSalary = baseSalary;
	}
	
	@Override
	public double getPaymentAmount() {
		return (getGrossSale() * getCommissionRate()) + baseSalary;
	}
	
	@Override
	public String toString() {
		return String.format("Gross Sales : %s%nCommission Rate : %s%nBase Salary : %s" , 
				             getGrossSale(), getCommissionRate(), getBaseSalary());
	}
	
}

public class SalariedEmployee extends Employee{
	
	private double weeklySalary;

	public SalariedEmployee(String firstName, String lastName, String sSN, double weeklySalary) {
		super(firstName, lastName, sSN);
		this.weeklySalary = weeklySalary;
	}

	public double getWeeklySalary() {
		return weeklySalary;
	}

	public void setWeeklySalary(double weeklySalary) {
		if(weeklySalary >= 0) {
			this.weeklySalary = weeklySalary;
		}
		else {
			throw new IllegalArgumentException("Weekly salary cannot be less than 0");
		}
	}
	
	@Override
	public double getPaymentAmount() {
		return getWeeklySalary();
	}

	@Override
	public String toString() {
		return String.format("Weekly Salary : %s" , 
				             getWeeklySalary());
	}
	
}
